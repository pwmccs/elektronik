

#include <16f877.h>
#device ADC=10
#fuses XT,NOWDT,NOPROTECT,NOBROWNOUT,NOLVP,NOPUT,NOWRT,NODEBUG,NOCPD
#use delay(clock=4000000)   // Gecikme fonksiyonu i�in kullan�lan osilat�r frekans� belirtiliyor
#use fast_io(b) // Port y�nlendirme komutlar� b portu i�in ge�erli
#IFNDEF EXP_OUT_ENABLE
#define EXP_OUT_ENABLE  PIN_B0
#define EXP_OUT_CLOCK   PIN_B1
#define EXP_OUT_DO      PIN_B2
#define NUMBER_OF_74595 4
#ENDIF
#include <74595.c>


// Ortak katot display i�in veri de�erleri
int digit[14]={63,6,91,79,102,109,125,7,127,111,99,88,64,80};
//            [0 ,1,2 ,3 , 4 , 5 , 6 ,7, 8 , 9 ,o ,c ,- ,r ]


/********* ANA PROGRAM FONKS�YONU********/

void main ()
{
   setup_psp(PSP_DISABLED);        // PSP birimi devre d���
   setup_timer_1(T1_DISABLED);     // T1 zamanlay�c�s� devre d���
   setup_timer_2(T2_DISABLED,0,1); // T2 zamanlay�c�s� devre d���
   setup_CCP1(CCP_OFF);            // CCP1 birimi devre d���
   setup_CCP2(CCP_OFF);            // CCP2 birimi devre d���
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_adc_ports(ALL_ANALOG);
   
   set_tris_b(0x00); // B portu t�m�yle ��k�� olarak y�nlendiriliyor
   output_b(0x00); // �lk anda B portu ��k��� s�f�rlan�yor
   int mask[4];//maske
   int data[4];//gonderilecek dizi//
   int16 OKUNAN;

   
while(TRUE)
                              {
      set_adc_channel(0);
      delay_ms(10);
      OKUNAN = read_adc();
 
mask[0]=(OKUNAN/1000)%10; //B�NLER
mask[1]=(OKUNAN/100)%10;  //Y�ZLER
mask[2]=(OKUNAN/10)%10;   //ONLAR
mask[3]= OKUNAN %10;     //B�RLER
                 
data[0] = digit[mask[0]];
data[1] = digit[mask[1]];
data[2] = digit[mask[2]];
data[3] = digit[mask[3]];

write_expanded_outputs(data);
delay_ms(500);
                 
                              }
                           }
