#include <16F628A.h>
#FUSES NOWDT, PUT, XT, MCLR, NOBROWNOUT, NOLVP
#use delay(clock=4000000)

#use fast_io(a)        
#use fast_io(b)

int8 sayac=0, saniye=0, dakika=0, saat=0, say=0;

#int_TIMER0
void timer0_kesmesi() {
if(++sayac == 61)  // timer0 61 kez ta�t�ysa
 {                 // 61 x 16.3 ms = 1 sn s�re ge�mi�tir
   sayac = 0;
   ++say;
      if(++saniye == 60) 
      {                
      saniye = 0;
         if(++dakika == 60) 
         {                
         dakika = 0;
            ++saat;
            
         }
      }
 }
}
   
void main() {
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   set_tris_a(0b11111111);
   set_tris_b(0x00);
   output_b(0x00);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_bit);      //16.3 ms overflow
   enable_interrupts(INT_TIMER0); //kesme aktif
   enable_interrupts(GLOBAL);

   while(TRUE) //ana d�ng�
   {
    while(saat==0){output_low(PIN_B0);}
    saat=0; say=0;
    while(say<5){output_high(PIN_B0);}   
   }

}
