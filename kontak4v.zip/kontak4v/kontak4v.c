#include <16f877A.h> 
#fuses HS,NOWDT,NOPROTECT,NOBROWNOUT,NOLVP,NOPUT,NOWRT,NODEBUG,NOCPD   
#device ADC=10
#use delay(clock = 4000000)

#use fast_io(a)        
#use fast_io(b)

int8 sayac=0, saniye=0, zaman=0, say=1, step=0, bayrak=0;
int16 limit=0, adcsonuc=0;

#int_TIMER0
void timer0_kesmesi() {
if(++sayac == 61)  // timer0 61 kez ta�t�ysa
 {                 // 61 x 16.3 ms = 1 sn s�re ge�mi�tir
   sayac = 0;
   if(zaman==0){zaman=6;}
   
      if(++saniye == zaman) 
      {                
      saniye=0;
      bayrak=1;
      ++step;
      if(step==1)
      {
      output_low(PIN_B0); 
      zaman=3;
      }
      if(step==2)
      {
        if(adcsonuc<limit){output_high(PIN_B0);}
      zaman=6;
      step=0;
      }
      
      
      
      if(++say==6)
      {bayrak=0;step=0;say=1;}
      }
 }
}
   
void main() {
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_adc_ports(AN0);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   set_tris_a(0xFF);  
   output_a(0x00);
   set_tris_b(0x00);  
   output_b(0x00);      
   
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_bit);      //16.3 ms overflow
   disable_interrupts(INT_TIMER0); //kesme pasif
   enable_interrupts(GLOBAL);
   
   limit=819; // 819 = 4v

   while(TRUE) //ana d�ng�
   {
    set_adc_channel(0);
    delay_ms(1);
    adcsonuc=read_adc(ADC_START_AND_READ);
    if(adcsonuc>limit)
    {output_low(PIN_B0);}
    else
    {
    if(!input(PIN_A1)) //Ba�la
      {
      if(step==0 && bayrak==0){output_high(PIN_B0);}
      enable_interrupts(INT_TIMER0); //kesme aktif
      bayrak=1;
      }
    }
    if(bayrak==0) 
    {disable_interrupts(INT_TIMER0);} 
   }

}
