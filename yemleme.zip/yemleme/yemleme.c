#include <16F628A.h>
#FUSES NOWDT, PUT, XT, MCLR, NOBROWNOUT, NOLVP
#use delay(clock=4000000)

#use fast_io(a)        
#use fast_io(b)

int8 sayac=0, saniye=0, dakika=0, saat=0, zaman=0, say=0, step=0, bayrak=0;
int motor[8]={0b11000011,0b11000110,0b11001100,0b11001001,0b11000110,0b11000011,0b11001001,0b11001100};

#int_TIMER0
void timer0_kesmesi() {
if(++sayac == 61)  // timer0 61 kez ta�t�ysa
 {                 // 61 x 16.3 ms = 1 sn s�re ge�mi�tir
   sayac = 0;
      if(++saniye == 60) 
      {                
      saniye = 0;
         if(++dakika == 60) 
         {                
         dakika = 0;
            if(++saat == zaman)
            { saat=0; bayrak=1;}
         }
      }
 }
}
   
void main() {
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   set_tris_a(0b11111111);
   set_tris_b(0x00);
   output_b(0b01000000);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_bit);      //16.3 ms overflow
   disable_interrupts(INT_TIMER0); //kesme pasif
   enable_interrupts(GLOBAL);

   while(TRUE) //ana d�ng�
   {
   if(!input(PIN_A1)) //Ba�la
      {
      zaman=12; //12saat s�re ayar�.
      enable_interrupts(INT_TIMER0); //kesme aktif
      while(!input(PIN_A1)){output_b(0b10000000);}
      }
   if(!input(PIN_A0)) //Dur
         {
         disable_interrupts(INT_TIMER0); //kesme pasif
         output_b(0b01000000);
         sayac=0; saniye=0; dakika=0; saat=0; bayrak=0;
         while(!input(PIN_A0)){output_b(0b01000000);}
         }               
   if(bayrak==1)
    {
    disable_interrupts(INT_TIMER0); //kesme pasif
    output_b(0);
    bayrak=0;
    step=0;
      for(say=0;say<12;say++) //motor ad�mlar�
        { 
        output_b(motor[step]);
        delay_ms(250); 
        if(++step==4){step=0;}
        }
    enable_interrupts(INT_TIMER0); //kesme aktif
    output_b(0b10000000);
    }
   }

}
