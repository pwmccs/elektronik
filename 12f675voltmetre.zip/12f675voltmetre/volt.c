#include <12F675.h>
#device adc=10
#FUSES NOWDT, INTRC_IO, NOMCLR, NOBROWNOUT
#use delay(clock=4000000)
#use FIXED_IO( A_outputs=PIN_A5,PIN_A4,PIN_A2 )
#define EXP_OUT_ENABLE  PIN_A2
#define EXP_OUT_CLOCK   PIN_A5
#define EXP_OUT_DO      PIN_A4
#define NUMBER_OF_74595 4
#include <74595.c>

// Ortak katot display i�in veri de�erleri
int digit[14]={63,6,91,79,102,109,125,7,127,111,99,88,64,80};
//            [0 ,1,2 ,3 , 4 , 5 , 6 ,7, 8 , 9 ,o ,c ,- ,r ]

void main() {
   setup_comparator(NC_NC_NC_NC);
   setup_adc_ports(sAN0);
   setup_adc(ADC_CLOCK_DIV_2);
   setup_vref(FALSE);
   int mask[4];//maske
   int data[4];//gonderilecek dizi//
   int16 ADC;
   delay_ms(250);

   while(TRUE)
   {
     set_adc_channel(0);
     delay_ms(10);
     ADC = (read_adc())*(3);
    
   if(ADC<3010)
   {
   mask[0]=(ADC/1000)%10; //B�NLER
   mask[1]=(ADC/100)%10;  //Y�ZLER
   mask[2]=(ADC/10)%10;   //ONLAR
   mask[3]= ADC %10;     //B�RLER
   } 
   else
   {
   mask[0]=12;
   mask[1]=12;  
   mask[2]=12;  
   mask[3]=12;  
   }
   
   data[0] = digit[mask[0]];
   data[1] = digit[mask[1]];
   data[2] = digit[mask[2]];
   data[3] = digit[mask[3]];
   
   write_expanded_outputs(data);
   delay_ms(100);
   }

}
