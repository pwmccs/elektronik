#include <16F628A.h>
#FUSES INTRC_IO, PUT, NOMCLR, NOBROWNOUT, NOLVP, NOCPD, NOPROTECT
#use delay(internal=4MHz)
#use fast_io(A)
#use fast_io(B)
#define sat_d   PIN_A0
#define sat_c   PIN_A1
#define sat_b   PIN_A6
#define sat_a   PIN_A7
#define sut_1   PIN_B0
#define sut_2   PIN_B1
#define sut_3   PIN_B2
#include <internal_eeprom.c>
char tus=0,bayrak=0;
int16 pwmduty=0,sayac=0;
char keypad_oku() 
{
   output_high(sut_1);
   output_high(sut_2);
   output_high(sut_3);
   tus=0;

   output_low(sut_1); 
   if (!input(sat_a))   
      { delay_ms(5); tus=1; }
   if (!input(sat_b))  
      { delay_ms(5); tus=4; }
   if (!input(sat_c))  
      { delay_ms(5); tus=7; }
   if (!input(sat_d))   
      { delay_ms(5); tus=0x0A; }
   output_high(sut_1); 

   output_low(sut_2); 
   if (!input(sat_a))   
      { delay_ms(5); tus=2; }
   if (!input(sat_b))  
      { delay_ms(5); tus=5; }
   if (!input(sat_c))  
      { delay_ms(5); tus=8; }
   if (!input(sat_d))   
      { delay_ms(5); tus=0x0B; }
   output_high(sut_2); 

   output_low(sut_3); 
   if (!input(sat_a))   
      { delay_ms(5); tus=3; }
   if (!input(sat_b))  
      { delay_ms(5); tus=6; }
   if (!input(sat_c))  
      { delay_ms(5); tus=9; }
   if (!input(sat_d))   
      { delay_ms(5); tus=0x0C; }
   output_high(sut_3); 
   
   if(tus>0){bayrak=1;sayac=0;}
   return tus; 
}
void main() {
   setup_timer_2(T2_DIV_BY_1,255,1);
   setup_ccp1(CCP_PWM);
   set_pwm1_duty((int16)0);
   set_tris_a(0xFF);
   set_tris_b(0x00);
   OUTPUT_B(0x00);
   delay_ms(250);
   pwmduty=read_int16_eeprom(0);
   delay_ms(10);
   if(pwmduty>1000){pwmduty=0;write_int16_eeprom(0,pwmduty);delay_ms(10);}
   set_pwm1_duty(pwmduty);

   while(TRUE){
   keypad_oku();
   if(tus==1){pwmduty=100;set_pwm1_duty(pwmduty);}
   if(tus==2){pwmduty=200;set_pwm1_duty(pwmduty);}
   if(tus==3){pwmduty=300;set_pwm1_duty(pwmduty);}
   if(tus==4){pwmduty=400;set_pwm1_duty(pwmduty);}
   if(tus==5){pwmduty=500;set_pwm1_duty(pwmduty);}
   if(tus==6){pwmduty=600;set_pwm1_duty(pwmduty);}
   if(tus==7){pwmduty=700;set_pwm1_duty(pwmduty);}
   if(tus==8){pwmduty=800;set_pwm1_duty(pwmduty);}
   if(tus==9){pwmduty=900;set_pwm1_duty(pwmduty);}
   if(tus==0x0A){if(pwmduty>0){--pwmduty;}set_pwm1_duty(pwmduty);}
   if(tus==0x0B){pwmduty=0;set_pwm1_duty(pwmduty);}
   if(tus==0x0C){if(++pwmduty>1000){pwmduty=1000;}set_pwm1_duty(pwmduty);}
   if(bayrak==1){delay_ms(1);if(++sayac==45000)
   {write_int16_eeprom(0,pwmduty);sayac=0;bayrak=0;
   output_high(PIN_B7);delay_ms(1000);output_low(PIN_B7);}
      } 
   }

}
