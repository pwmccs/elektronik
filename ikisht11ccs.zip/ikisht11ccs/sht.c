#include <16F877.h>

#FUSES NOWDT                    //No Watch Dog Timer
#FUSES XT                       //Crystal osc <= 4mhz for PCM/PCH , 3mhz to 10 mhz for PCD
#FUSES NOPUT                    //No Power Up Timer
#FUSES PROTECT                  //Code protected from reads
#FUSES NOBROWNOUT               //No brownout reset
#FUSES NOLVP                    //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
#FUSES NOCPD                    //No EE protection
#FUSES NOWRT                    //Program memory not write protected
#FUSES NODEBUG                  //No Debug mode for ICD

#use delay(clock=4000000)

#define LCD_RS_PIN      PIN_D1 
#define LCD_RW_PIN      PIN_D2
#define LCD_ENABLE_PIN  PIN_D0 
#define LCD_DATA4       PIN_D4 
#define LCD_DATA5       PIN_D5 
#define LCD_DATA6       PIN_D6 
#define LCD_DATA7       PIN_D7
#include <LCD.C>


#define sht1_data_pin   PIN_b1
#define sht1_clk_pin    PIN_b0
#define sht2_data_pin   PIN_b3
#define sht2_clk_pin    PIN_b2
#include <sensor1.c>
#include <sensor2.c>


void main()
{
 float restemp, truehumid;
 lcd_init();
 sht1_init();
 sht2_init();
 
 while(TRUE)
 {
  sht1_rd (restemp, truehumid);
  lcd_gotoxy(1,1); 
  printf(lcd_putc,"Temp1 : %3.1f %cC   ", restemp, 223);
  printf(lcd_putc,"\nRH1   : %3.1f %%   ", truehumid);
  delay_ms(3000); 
  
  sht2_rd (restemp, truehumid);
  lcd_gotoxy(1,1); 
  printf(lcd_putc,"Temp2 : %3.1f %cC   ", restemp, 223);
  printf(lcd_putc,"\nRH2   : %3.1f %%   ", truehumid);
  delay_ms(3000);
 }
}

