//***** SHT75 Ba�latma *****

void comstart2 (void)
{
 output_float(sht2_data_pin);  //data high
 output_bit(sht2_clk_pin, 0);  //clk low
 delay_us(1);
 output_bit(sht2_clk_pin, 1);  //clk high
 delay_us(1);
 output_bit(sht2_data_pin, 0); //data low
 delay_us(1);
 output_bit(sht2_clk_pin, 0);  //clk low
 delay_us(2);
 output_bit(sht2_clk_pin, 1);  //clk high
 delay_us(1);
 output_float(sht2_data_pin);  //data high
 delay_us(1);
 output_bit(sht2_clk_pin, 0);  //clk low
}


//***** SHT75 yazma fonksiyonu*****

int1 comwrite2 (int8 iobyte)
{
 int8 i, mask = 0x80;
 int1 ack;

 //Komut g�nderilir
 delay_us(4);
 for(i=0; i<8; i++)
  {
   output_bit(sht2_clk_pin, 0);                          //clk low
   if((iobyte & mask) > 0) output_float(sht2_data_pin);  //data high if MSB high
   else output_bit(sht2_data_pin, 0);                    //data low if MSB low
   delay_us(1);
   output_bit(sht2_clk_pin, 1);                          //clk high
   delay_us(1);
   mask = mask >> 1;                                    //shift to next bit
  }

 //Shift in ack
 output_bit(sht2_clk_pin, 0);  //clk low
 delay_us(1);
 ack = input(sht2_data_pin);   //get ack bit
 output_bit(sht2_clk_pin, 1);  //clk high
 delay_us(1);
 output_bit(sht2_clk_pin, 0);  //clk low
 return(ack);
}


//***** Function to read data from SHT75 *****

int16 comread2 (void)
{
 int8 i;
 int16 iobyte = 0;
 const int16 mask0 = 0x0000;
 const int16 mask1 = 0x0001;

 //shift in MSB data
 for(i=0; i<8; i++)
  {
   iobyte = iobyte << 1;
   output_bit(sht2_clk_pin, 1);                //clk high
   delay_us(1);
   if (input(sht2_data_pin)) iobyte |= mask1;  //shift in data bit
   else iobyte |= mask0;
   output_bit(sht2_clk_pin, 0);                //clk low
   delay_us(1);
  }

 //send ack 0 bit
 output_bit(sht2_data_pin, 0); //data low
 delay_us(1);
 output_bit(sht2_clk_pin, 1);  //clk high
 delay_us(2);
 output_bit(sht2_clk_pin, 0);  //clk low
 delay_us(1);
 output_float(sht2_data_pin);  //data high

 //shift in LSB data
 for(i=0; i<8; i++)
  {
   iobyte = iobyte << 1;
   output_bit(sht2_clk_pin, 1);                //clk high
   delay_us(1);
   if (input(sht2_data_pin)) iobyte |= mask1;  //shift in data bit
   else iobyte |= mask0;
   output_bit(sht2_clk_pin, 0);                //clk low
   delay_us(1);
  }

 //send ack 1 bit
 output_float(sht2_data_pin);  //data high
 delay_us(1);
 output_bit(sht2_clk_pin, 1);  //clk high
 delay_us(2);
 output_bit(sht2_clk_pin, 0);  //clk low

 return(iobyte);
}


//***** Function to wait for SHT75 reading *****

void comwait2 (void)
{
 int16 sht2_delay;

 output_float(sht2_data_pin);                     //data high
 output_bit(sht2_clk_pin, 0);                     //clk low
 delay_us(1);
 for(sht2_delay=0; sht2_delay<30000; sht2_delay++)  // wait for max 300ms
  {
   if (!input(sht2_data_pin)) break;              //if sht2_data_pin low, SHT75 ready
   delay_us(10);
  }
}


//***** Function to reset SHT75 communication *****

void comreset2 (void)
{
 int8 i;

 output_float(sht2_data_pin);    //data high
 output_bit(sht2_clk_pin, 0);    //clk low
 delay_us(2);
 for(i=0; i<9; i++)
  {
   output_bit(sht2_clk_pin, 1);  //toggle clk 9 times
   delay_us(2);
   output_bit(sht2_clk_pin, 0);
   delay_us(2);
 }
 comstart2();
}


//***** Function to soft reset SHT75 *****

void sht2_soft_reset (void)
{
 comreset2();           //SHT75 communication reset
 comwrite2(0x1e);       //send SHT75 reset command
 delay_ms(15);         //pause 15 ms
}


//***** Function to measure SHT75 temperature *****

int16 measuretemp2(void)
{
 int1 ack;
 int16 iobyte;

 comstart2();             //alert SHT75
 ack = comwrite2(0x03);   //send measure temp command and read ack status
 if(ack == 1) return;
 comwait2();              //wait for SHT75 measurement to complete
 iobyte = comread2();     //read SHT75 temp data
 return(iobyte);
}


//***** Function to measure SHT75 RH *****

int16 measurehumid2(void)
{
 int1 ack;
 int16 iobyte;

 comstart2();            //alert SHT75
 ack = comwrite2(0x05);  //send measure RH command and read ack status
 if(ack == 1) return;
 comwait2();             //wait for SHT75 measurement to complete
 iobyte = comread2();    //read SHT75 temp data
 return(iobyte);
}


//***** Function to calculate SHT75 temp & RH *****

void calculate_data2 (int16 temp, int16 humid, float & tc, float & rhlin, float & rhtrue)
{
 float truehumid1, rh;

 //calculate temperature reading
 tc = ((float) temp * 0.01) - 40.0;

 //calculate Real RH reading
 rh = (float) humid;

 rhlin = (rh * 0.0405) - (rh * rh * 0.0000028) - 4.0;

 //calculate True RH reading
 rhtrue = ((tc - 25.0) * (0.01 + (0.00008 * rh))) + rhlin;
}


//***** Function to measure & calculate SHT75 temp & RH *****

void sht2_rd (float & temp, float & truehumid)
{
 int16 restemp, reshumid;
 float realhumid;
 restemp = 0; truehumid = 0;

 restemp = measuretemp2();    //measure temp
 reshumid = measurehumid2();  //measure RH
calculate_data2 (restemp, reshumid, temp, realhumid, truehumid);  //calculate temp & RH
}


//***** Function to initialise SHT75 on power-up *****

void sht2_init (void)
{
 comreset2();    //reset SHT75
 delay_ms(20);  //delay for power-up
}
