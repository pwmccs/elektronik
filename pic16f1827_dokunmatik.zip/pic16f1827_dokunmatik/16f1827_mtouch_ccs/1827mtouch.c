#include <16F1827.h>
#FUSES NOPUT, NOMCLR, NOPROTECT, NOCPD, NOBROWNOUT, NOCLKOUT, NOIESO, NOFCMEN, NOWRT, NOSTVREN, BORV25, NOLVP
#use delay(internal=8000000)
#byte CPSCON0 = 0x1E
#byte CPSCON1 = 0x1F
#bit CPSON = 0x1E.7
#use fast_io(A)
#use fast_io(B)
int1 flag=0;
int16 cap=0;

void  TIMER1_KESME(void) 
      {cap=0;}
      
void cpsenskur()
      {
      CPSCON0 = 0b00001100;
      CPSCON1 = 0x00;
      } 
void cpkanal(int8 cnl)
      {
      CPSCON1=cnl;
      Delay_ms(16);
      }
void dokunmatik()
      {
      CPSON = 0;
      cap=get_timer1();
      if ((cap >> 8) > 15) // !!! (15) E�ik de�eridir.
         {
         flag=0; // Not touch
         }
         else 
         {
          flag=1; // Touch
         }
      set_timer1(0);
      CPSON=1;
      }
      
void main() { 
   set_tris_a(0b11111111);
   set_tris_b(0b00000000);
   output_a(0x00);
   output_b(0x00);
   setup_comparator(NC_NC_NC_NC);
   setup_timer_1(T1_CAPSENSE|T1_DIV_BY_1);
   delay_ms(250);
   cpsenskur();
   
   while(TRUE)
   {
      cpkanal(0);	//dokunmatik kanal
      dokunmatik();
      if (flag==1){output_high(PIN_B0); flag=0;}else{output_low(PIN_B0);}
      
      cpkanal(1);
      dokunmatik();
      if (flag==1){output_high(PIN_B1); flag=0;}else{output_low(PIN_B1);}
 
      cpkanal(2);
      dokunmatik();
      if (flag==1){output_high(PIN_B2); flag=0;}else{output_low(PIN_B2);}
      
      cpkanal(3);
      dokunmatik();
      if (flag==1){output_high(PIN_B3); flag=0;}else{output_low(PIN_B3);}
   }

}

    

         
