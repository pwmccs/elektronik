#define THRESHOLD_H 15	// Eşik değeri.

unsigned int cap;
unsigned bit flag;

void dokunmatik (void) {
     CPSCON0.CPSON = 0;

     cap = (TMR1H << 8) + TMR1L;

     if ((cap >> 8) > THRESHOLD_H) {
          flag=0;                     // Not touch
     } else {
          flag=1;                     // Touch
     }

     TMR1L=0;
     TMR1H=0;
     CPSCON0.CPSON=1;
}

void main() {
     cap = 0;
     flag = 0;
     OSCCON = 0x70;             // Internal 8MHz clock
     ANSELA = 0xff;
     ANSELB = 0x00;
     TRISA = 0xff;
     TRISB = 0x00;
     PORTA=0x00;
     PORTB=0x00;
     CPSCON0 = 0b00001100;      // 11 = Oscillator is in high range. Charge/discharge current is nominally 18 uA.
     CPSCON1 = 0x00;            // Port select
     T1CON = 0b11000001;
     T1GCON.TMR1GE = 0;
     TMR1L=0;
     TMR1H=0;
     CPSCON0.CPSON = 1;
     
     Delay_ms(250);
     
     while(1) {
            CPSCON1 = 0x00;	//dokunmatik kanal
            Delay_ms(16);
            dokunmatik();
            if (flag==1){PORTB.RB0=1; flag=0;}else{PORTB.RB0=0;}

            CPSCON1 = 0x01;
            Delay_ms(16);
            dokunmatik();
            if (flag==1){PORTB.RB1=1; flag=0;}else{PORTB.RB1=0;}
            
            CPSCON1 = 0x02;
            Delay_ms(16);
            dokunmatik();
            if (flag==1){PORTB.RB2=1; flag=0;}else{PORTB.RB2=0;}
            
            CPSCON1 = 0x03;
            Delay_ms(16);
            dokunmatik();
            if (flag==1){PORTB.RB3=1; flag=0;}else{PORTB.RB3=0;}

    }
}