#include <16F628.h>
#FUSES INTRC_IO, PUT, NOMCLR, BROWNOUT, NOLVP, NOCPD, NOPROTECT, NOWDT
#use delay(internal=4MHz)
#use STANDARD_IO(A)
#USE FAST_IO (B)
#define DIG1   PIN_A0
#define DIG2   PIN_A1
#define DIG3   PIN_A2
#define DIG4   PIN_A3
#INCLUDE <stdlib.h>
#include <ds18b20.c>
float termo=0;
int sayac=0,hata=0;
int16 ekran=0,sayi=0;
char BIR,ON,YUZ,BIN;
char hane1=16,hane2=16,hane3=16,hane4=16,nokta=0;
int digit[18]={192,249,164,176,153,146,130,248,128,144,156,191,137,177,136,255,00,207};
//            [ 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , o , - , H , t , A ,   ,8., I ]

#INT_TIMER0
void  TIMER0_KESME(void) 
{
     output_b(0xff);
     if (++sayac==5){sayac=1;}
         switch(sayac)  
         {
            case 1:  
            output_low(DIG1);
            output_high(DIG2);
            output_high(DIG3);
            output_high(DIG4);
            output_b(digit[hane1]);
            break;
            case 2:
            output_high(DIG1);
            output_low(DIG2);
            output_high(DIG3);
            output_high(DIG4);
            output_b(digit[hane2]);
            if(nokta==1) output_low(PIN_B7);
            break;
            case 3:
            output_high(DIG1);
            output_high(DIG2);
            output_low(DIG3);
            output_high(DIG4);
            output_b(digit[hane3]);
            break;
            case 4:
            output_high(DIG1);
            output_high(DIG2);
            output_high(DIG3);
            output_low(DIG4);
            output_b(digit[hane4]);
            break;
         }     
       }
void ds_kontrol()
   {
   set_timer0(0);
   output_low(PIN_A4);
   delay_us(500);
   input(PIN_A4);
   delay_us(100);
   if(input(PIN_A4))
   {hata=1;}
   else
   {hata=0;}  
   delay_ms(100);
   }
void main()
{
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_8|RTCC_8_bit);
   setup_comparator(NC_NC_NC_NC);
   output_a(0x00);
   set_tris_b(0x00); 
   output_b(0xff); 
   enable_interrupts(INT_TIMER0);
   enable_interrupts(GLOBAL);
   termo = ds1820_read();
   set_timer0(0);
   delay_ms(1000);
   
   while(TRUE)
   {
    ds_kontrol();
    if(hata==0)
     {
      termo = ds1820_read();
      ekran=abs(termo*10);
      sayi=ekran;
      
      BIR=0; ON=0; YUZ=0; BIN=0;
      WHILE(ekran>=1000){ekran=ekran-1000,BIN++;}
      WHILE(ekran>=100){ekran=ekran-100,YUZ++;}
      WHILE(ekran>=10){ekran=ekran-10,ON++;}
      WHILE(ekran>=1){ekran=ekran-1,BIR++;}
      
      if(termo<0)//s�cakl�k negatifse - g�ster
         {
            if(YUZ==0)
               {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=11;}
            else
               {hane4=10; nokta=0; hane3=ON; hane2=YUZ; hane1=11;}
         }
      else
         {
            if(BIN==0)
               {  
                  if(YUZ==0)
                      {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=15;}
                  else 
                      {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=YUZ;}
               }
            else
               {
                hane4=10; nokta=0; hane3=ON; hane2=YUZ; hane1=BIN;
               }
         }
      
      delay_ms(100);
   }  
   else
   { nokta=0; hane4=14; hane3=13; hane2=14; hane1=12; delay_ms(500);}//sens�r hatas�n� g�ster
   }
 }
