// CCS PICC 4 Bit Keypad �rnek Uygulamas�  //

#include <16F628A.h>
#FUSES INTRC_IO, NOPUT, NOMCLR, NOBROWNOUT, NOLVP, NOCPD, NOPROTECT 
#use delay(internal=4MHz) // dahili 4Mhz osilat�r
#use fast_io(A)
#define LCD_ENABLE_PIN PIN_B3
#define LCD_RS_PIN PIN_B1
#define LCD_RW_PIN PIN_B2
#define LCD_DATA4 PIN_B4
#define LCD_DATA5 PIN_B5
#define LCD_DATA6 PIN_B6
#define LCD_DATA7 PIN_B7
#include <lcd.c>

int8 t1=0, t2=0, t3=0, t4=0;
int16 keykod=0;
char tus=0;

void keypadtara() {
   set_tris_a(0b11111110);   //A0 pini ��k�� yap
   output_low(PIN_A0);      //A0 lojik 0
   delay_us(100);
   t1 = (input_a()&0b00001111); //PortA ilk 4 bitini oku 
   bit_clear(t1,0);         //��k�� bitini lojik 0 olarak i�le
    
   set_tris_a(0b11111101);   //A1 pini ��k�� yap
   output_low(PIN_A1);      //A1 lojik 0
   delay_us(100);
   t2 = (input_a()&0b00001111); //PortA ilk 4 bitini oku
   bit_clear(t2,1);         //��k�� bitini lojik 0 olarak i�le
    
   set_tris_a(0b11111011);   //A2 pini ��k�� yap
   output_low(PIN_A2);      //A2 lojik 0
   delay_us(100);
   t3 = (input_a()&0b00001111); //PortA ilk 4 bitini oku
   bit_clear(t3,2);         //��k�� bitini lojik 0 olarak i�le

   
   set_tris_a(0b11110111);   //A3 pini ��k�� yap
   output_low(PIN_A3);      //A3 lojik 0
   delay_us(100);
   t4 = (input_a()&0b00001111); //PortA ilk 4 bitini oku
   bit_clear(t4,3);         //��k�� bitini lojik 0 olarak i�le
   
   set_tris_a(0b11111111);   //PortA tamamen giri�
   tus=0;
   keykod=0;
   keykod=((keykod+=((t1<<=4)+t2))<<8)+((t3<<=4)+t4); //make16(); 16bit kod d�n���m�
   //t1=highbyte MSB, t2=highbyte LSB, t3=lowbyte MSB, t4=lowbyte LSB.
   
   while(TRUE){
   if(keykod==0xEDB7){tus=' '; break;} 
   if(keykod==0xEDA6){tus='1'; break;}
   if(keykod==0xECB6){tus='2'; break;}
   if(keykod==0xEDB6){tus='3'; break;}
   if(keykod==0xED95){tus='4'; break;}
   if(keykod==0xEDB5){tus='5'; break;}
   if(keykod==0xCDB5){tus='6'; break;}
   if(keykod==0xEDB3){tus='7'; break;}
   if(keykod==0xE9B3){tus='8'; break;}
   if(keykod==0xADB3){tus='9'; break;}
   if(keykod==0xE5B7){tus='0'; break;}
   if(keykod==0xECA7){tus='A'; break;}
   if(keykod==0xED97){tus='B'; break;}
   if(keykod==0xE9B7){tus='C'; break;}
   if(keykod==0xE537){tus='D'; break;}
   if(keykod==0xED37){tus='*'; break;}
   if(keykod==0x6DB7){tus='#'; break;}
   tus='-'; break;
   }
   
   }
void main() {
   setup_comparator(NC_NC_NC_NC);
   set_tris_a(0xFF); //PORTA G�R�ޞ
   set_tris_b(0x00);//PORTB �IKI�
   lcd_init(); //LCD Ba�lat
   delay_ms(250); //Ba�lang�� Gecikmesi

   while(TRUE){
   keypadtara(); //keypad okunup sonu� tus de�i�kenine yaz�l�r.
   lcd_gotoxy(1,1);
   printf(lcd_putc,"KEYPAD KOD= %LX",keykod,);
   lcd_gotoxy(1,2);
   printf(lcd_putc,"BASILAN TUS= [%c]",tus,);
   }

}
