#include <16F1827.h>
#device ADC=10
#FUSES NOPUT, NOMCLR, NOPROTECT, NOCPD, NOBROWNOUT, NOCLKOUT, NOIESO, NOFCMEN, NOWRT, STVREN, BORV25, NOLVP
#use delay(internal=8MHz)
#use FIXED_IO( A_outputs=PIN_A4,PIN_A3 )
#use FIXED_IO( B_outputs=PIN_B7,PIN_B6,PIN_B5,PIN_B4,PIN_B3,PIN_B2,PIN_B1,PIN_B0 )
int16 pwm1=500,pwm2=500,pwm3=500,pwm4=500;

void main() {
   setup_adc_ports(sAN0|sAN1);
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_timer_2(T2_DIV_BY_16,255,1);
   setup_ccp1(CCP_PWM|CCP_SHUTDOWN_AC_L|CCP_SHUTDOWN_BD_L);
   setup_ccp2(CCP_PWM|CCP_SHUTDOWN_AC_L|CCP_SHUTDOWN_BD_L);
   setup_ccp3(CCP_PWM);
   setup_ccp4(CCP_PWM);
   OUTPUT_B(0x00);
   set_pwm1_duty((int16)0);
   set_pwm2_duty((int16)0);
   set_pwm3_duty((int16)0);
   set_pwm4_duty((int16)0);
   delay_ms(250);
   
   while(TRUE){
   
      set_adc_channel(0);
      delay_ms(1);
      pwm1=read_adc();
      set_pwm1_duty(pwm1);
      
      set_adc_channel(1);
      delay_ms(1);
      pwm2=read_adc();
      set_pwm2_duty(pwm2);
      
      delay_ms(1);
      if(!input(PIN_A2))
      {if(++pwm3>1000){pwm3=1000;}}
      if(!input(PIN_A5))
      {if(--pwm3==0){pwm3=1;}}
      set_pwm3_duty(pwm3);
      
      delay_ms(1);
      if(!input(PIN_A6))
      {if(++pwm4>1000){pwm4=1000;}}
      if(!input(PIN_A7))
      {if(--pwm4==0){pwm4=1;}}
      set_pwm4_duty(pwm4);
}

}
