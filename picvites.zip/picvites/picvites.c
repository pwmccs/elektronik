
void main() {
     CMCON = 7;
     trisa = 0xff;
     porta = 0;
     trisb = 0;
     portb = 0;
     
     while(1)
     {
     switch (porta) {
     case 0: portb=0x3F;  break;
     case 1: portb=0x06;  break;
     case 2: portb=0x5B; break;
     case 4: portb=0x4F;  break;
     case 8: portb=0x66;  break;
     case 16: portb=0x6D; break;
     case 32: portb=68; break;
     default: portb=0;
     }
     }
}