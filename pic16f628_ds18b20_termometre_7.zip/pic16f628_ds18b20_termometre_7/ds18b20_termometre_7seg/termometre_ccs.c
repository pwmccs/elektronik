#include <16F628.h>
#FUSES INTRC_IO, PUT, NOMCLR, BROWNOUT, NOLVP, NOCPD, NOPROTECT, NOWDT
#use delay(internal=4MHz)
#use STANDARD_IO(A)
#USE FAST_IO (B)
#define DIG1   PIN_A0
#define DIG2   PIN_A1
#define DIG3   PIN_A2
#define DIG4   PIN_A3
#define ONE_WIRE_PIN PIN_A4
#INCLUDE <stdlib.h>
float termo=0;
int sayac=0,hata=0;
int16 ekran=0,sayi=0;
char BIR,ON,YUZ,BIN;
char hane1=16,hane2=16,hane3=16,hane4=16,nokta=0;
int digit[18]={192,249,164,176,153,146,130,248,128,144,156,191,137,177,136,255,00,207};
//            [ 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , o , - , H , t , A ,   ,8., I ]

void ekran_tara(int sayac)
   {
   for(int i=0;i<sayac;i++)
   {
   output_b(0xff);
   output_low(DIG1);
   output_high(DIG2);
   output_high(DIG3);
   output_high(DIG4);
   output_b(digit[hane1]);
   delay_ms(4);
   output_b(0xff);
   output_high(DIG1);
   output_low(DIG2);
   output_high(DIG3);
   output_high(DIG4);
   output_b(digit[hane2]);
   if(nokta==1) output_low(PIN_B7);
   delay_ms(4);
   output_b(0xff);
   output_high(DIG1);
   output_high(DIG2);
   output_low(DIG3);
   output_high(DIG4);
   output_b(digit[hane3]);
   delay_ms(4);
   output_b(0xff);
   output_high(DIG1);
   output_high(DIG2);
   output_high(DIG3);
   output_low(DIG4);
   output_b(digit[hane4]); 
   delay_ms(4);
   output_b(0xff);
   }
   }
   
//........DS18B20.LIB.......//       
void onewire_reset() 
   {
   output_low(ONE_WIRE_PIN);
   delay_us( 500 ); 
   output_float(ONE_WIRE_PIN); 
   delay_us( 500 );
   output_float(ONE_WIRE_PIN);
   } 

void onewire_write(int data)
   {
   int count;
   for (count=0; count<8; ++count)
   {
   output_low(ONE_WIRE_PIN);
   delay_us( 2 ); 
   output_bit(ONE_WIRE_PIN, shift_right(&data,1,0));
   delay_us( 60 ); 
   output_float(ONE_WIRE_PIN);
   delay_us( 2 ); 
   }
   } 

int onewire_read()
   {
   int count, data;
   for (count=0; count<8; ++count)
   {
   output_low(ONE_WIRE_PIN);
   delay_us( 2 ); 
   output_float(ONE_WIRE_PIN);
   delay_us( 8 );
   shift_right(&data,1,input(ONE_WIRE_PIN));
   delay_us( 120 );
   }
   return( data );
   } 

float ds1820_read()
   {
   int8 busy=0, temp1, temp2;
   signed int16 temp3;
   float result;
   onewire_reset();
   ekran_tara(1);
   onewire_write(0xCC);
   ekran_tara(1);
   onewire_write(0x44);
   while (busy == 0)
   {busy = onewire_read();ekran_tara(1);}
   onewire_reset();
   ekran_tara(1);
   onewire_write(0xCC);
   ekran_tara(1);
   onewire_write(0xBE);
   ekran_tara(1);
   temp1 = onewire_read();
   ekran_tara(1);
   temp2 = onewire_read();
   ekran_tara(1);
   temp3 = make16(temp2, temp1);
   result = (float) temp3 / 16.0;
   ekran_tara(25);
   return(result);
   }  
//..........................// 
       
void ds_kontrol()
   {
   output_low(ONE_WIRE_PIN);
   delay_us(500);
   input(ONE_WIRE_PIN);
   delay_us(100);
   if(input(ONE_WIRE_PIN))
   {hata=1;}
   else
   {hata=0;}
   }

void main()
{
   setup_comparator(NC_NC_NC_NC);
   output_a(0x00);
   set_tris_b(0x00); 
   output_b(0xff); 
   delay_ms(250);
   termo = ds1820_read();   
   ekran_tara(10);
   
   while(TRUE)
   {
    ds_kontrol();
    if(hata==0)
     {
      termo = ds1820_read();
      ekran=abs(termo*10);
      sayi=ekran;
      
      BIR=0; ON=0; YUZ=0; BIN=0;
      WHILE(ekran>=1000){ekran=ekran-1000,BIN++;}
      WHILE(ekran>=100){ekran=ekran-100,YUZ++;}
      WHILE(ekran>=10){ekran=ekran-10,ON++;}
      WHILE(ekran>=1){ekran=ekran-1,BIR++;}
      
      if(termo<0)//s�cakl�k negatifse - g�ster
         {
            if(YUZ==0)
               {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=11;}
            else
               {hane4=10; nokta=0; hane3=ON; hane2=YUZ; hane1=11;}
         }
      else
         {
            if(BIN==0)
               {  
                  if(YUZ==0)
                      {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=15;}
                  else 
                      {hane4=10; hane3=BIR; nokta=1; hane2=ON; hane1=YUZ;}
               }
            else
               {
                hane4=10; nokta=0; hane3=ON; hane2=YUZ; hane1=BIN;
               }
         }
      
      ekran_tara(2);
   }  
   else
   { nokta=0; hane4=14; hane3=13; hane2=14; hane1=12; ekran_tara(30);}//sens�r hatas�n� g�ster
   }
 }
