//BU UYGULAMA G�R�� VOLTAJINA G�RE PWM �IKARIR. DE�ER EKRANDAN OKUNUR VE + - BUTONLARI �LE DE���T�REB�L�N�R.
#include <16F876A.h>
#device ADC=10
#fuses HS,NOWDT,NOPROTECT,NOLVP
#use delay(clock = 4000000)  
#byte CCPR1L = 0x15
#byte CCP1CON = 0x17  
#bit CCP1CONY = 0x17.4
#bit CCP1CONX = 0x17.5

char birler=0, onlar=0 ;
// Ortak katot display i�in veri de�erleri
int digit[16]={63,6,91,79,102,109,125,7,127,111,119,56,57,94,121,113};
//            [0 ,1,2 ,3 , 4 , 5 , 6 ,7, 8 , 9 , a , L ,c ,d , e , f ]
int16 adcsonuc=0, adcvolt=0, gerilim=0, pwmvolt=0, eksivolt=0;
int8 say=0;
void adc_oku()
      {      
      set_adc_channel(0);
      delay_ms(1);
      adcsonuc=read_adc(ADC_START_AND_READ);             
      }
      
void ekran()
      {   
   output_low(PIN_C1);  
   output_b(digit[birler]); 
   delay_ms(5);           
   output_high(PIN_C1);  
   output_low(PIN_C0); 
   output_b(digit[onlar]);
   output_high(PIN_B7);    //nokta
   delay_ms(5);            
   output_high(PIN_C0);
      } 
void volt_hesap()
   {
   adcvolt=adcsonuc;
   adcvolt++;
   gerilim=(0.0048875855*adcvolt)*10;  
   birler=gerilim%10;  // birler hanesi hesaplan�yor
   onlar=gerilim/10;   // onlar hanesi hesaplan�yor
   }
void pwm_hesap()
   {
   
   if(eksivolt>1)
   {
   if(eksivolt<adcsonuc)
   {adcsonuc=adcsonuc-eksivolt;}
   else
   {adcsonuc=0;}
   }
   else
   {
   if((adcsonuc+pwmvolt)<=1023)
   {adcsonuc=adcsonuc+pwmvolt;}
   else
   {adcsonuc=1023;}
   }
   
   CCP1CONY=bit_test(adcsonuc,0);
   CCP1CONX=bit_test(adcsonuc,1); 
   CCPR1L=adcsonuc>>2;
   }
      
void main(void)
{
   /* adc mod�l� ayarlan�yor */
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_adc_ports(AN0);
   setup_ccp1(CCP_PWM); 
   set_pwm1_duty(1);
   setup_comparator(NC_NC_NC_NC);
   set_tris_b(0x00);  
   output_b(0x00);      
   set_tris_c(0x00);   
   output_c(0x00);
 
   
   while(TRUE)
  {
   adc_oku();   
   pwm_hesap();   
   volt_hesap();
   ekran(); 
   
   if(!input(PIN_A5))
   {
   if((pwmvolt<=1020)&&(eksivolt<1))
   {pwmvolt=pwmvolt+20;}
   if(eksivolt>=20)
   {eksivolt=eksivolt-20;}
   adc_oku();
   pwm_hesap();   
   volt_hesap();
   while (!input(PIN_A5))
   {ekran();}
   }
   
   if(!input(PIN_A4))
   {
   if(pwmvolt>=20)
   {pwmvolt=pwmvolt-20;} 
   if((eksivolt<=1020)&&(pwmvolt<1))
   {eksivolt=eksivolt+20;}
   adc_oku();
   pwm_hesap();   
   volt_hesap();
   while (!input(PIN_A4))
   {ekran();}
   }
    
    }
}

