#include <16F628A.h>
#FUSES NOWDT, PUT, XT, MCLR, NOBROWNOUT, NOLVP
#use delay(clock=4000000)

#use fast_io(a)        
#use fast_io(b)

int8 sayac=0, led1=0, led2=0, led3=0 ;

#int_TIMER0
void timer0_kesmesi() {
if(++sayac == 61)  // timer0 61 kez ta�t�ysa
 {                 // 61 x 16.3 ms = 1 sn s�re ge�mi�tir
   sayac = 0;
   if(++led1 == 60) // 60 saniye
      {                
      output_low(PIN_B0);
      led1=0;
      }
   if(++led2 == 60) // 60 saniye 
      {                
      output_low(PIN_B1);
      led2=0;
      }
   if(++led3 == 60) // 60 saniye 
      {                
      output_low(PIN_B2);
      led3=0;
      }
 }
}
   
void main() {
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   set_tris_a(0b11111111);
   set_tris_b(0x00);
   output_b(0b01000000);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_bit);      //16.3 ms overflow
   enable_interrupts(INT_TIMER0); //kesme aktif
   enable_interrupts(GLOBAL);

   while(TRUE) //ana d�ng�
   {
   
   if(!input(PIN_A0)) //buton1
      {
      led1=0;
      output_high(PIN_B0);
      while(!input(PIN_A0)){}
      }                
   if(!input(PIN_A1)) //buton2
      {
      led2=0;
      output_high(PIN_B1);
      while(!input(PIN_A1)){}
      }
    if(!input(PIN_A2)) //buton3
      {
      led3=0;
      output_high(PIN_B2);
      while(!input(PIN_A2)){}
      }  
   }

}
