#include <16F628A.h>
#FUSES PUT, NOMCLR, NOBROWNOUT, NOLVP, NOCPD, NOPROTECT
#use delay(crystal=4000000)

#define LCD_ENABLE_PIN PIN_A2
#define LCD_RS_PIN PIN_A0
#define LCD_RW_PIN PIN_A1
#define LCD_DATA4 PIN_B0
#define LCD_DATA5 PIN_B1
#define LCD_DATA6 PIN_B2
#define LCD_DATA7 PIN_B3
#include <lcd.c>

int8 sayac=0, saniye=0, bayrak=0;
int16 tmrsayac=0,tmrsay=0;

#INT_TIMER0
void  TIMER0_kesme(void) {
if(++sayac == 61)  // timer0 61 kez ta�t�ysa
 {                 // 61 x 16.3 ms = 1 sn s�re ge�mi�tir
   sayac = 0;
      if(++saniye == 60) // 60 Saniye
      {                
      tmrsay=get_timer1();
      tmrsayac=tmrsay;
      set_timer1(0); 
      bayrak=1;
      }
 }
}

void ekran(int16 sonuc){
   lcd_gotoxy(1,1);
   printf(lcd_putc," saniye=%d       \n sayac=%lu   ",saniye,sonuc);
   }

void main() {
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_BIT);      //16,3 ms overflow
   setup_timer_1(T1_EXTERNAL|T1_DIV_BY_1); 
   output_low(PIN_B4);
   lcd_init();
   delay_ms(250);
   disable_interrupts(INT_TIMER0);
   enable_interrupts(GLOBAL);
   set_timer1(0); 

   while(TRUE){
   ekran(tmrsay);
   if(!input(PIN_A4)){
      saniye = 0;
      bayrak=0;
      enable_interrupts(INT_TIMER0);
      output_high(PIN_B4);
      set_timer1(0);  
      do{
      ekran(tmrsayac);
      tmrsayac=get_timer1();
      if(!input(PIN_A5)){saniye = 0; bayrak=0; tmrsay=0; break;}
      }while(bayrak==0);
      output_low(PIN_B4);
      disable_interrupts(INT_TIMER0);
      while(!input(PIN_A5)){delay_ms(1);}
      while(!input(PIN_A4)){set_timer1(0);} 
   }
   
   if(!input(PIN_A5)){saniye = 0; tmrsay=0;} // sayaclar� s�f�rla
   
   }

}
