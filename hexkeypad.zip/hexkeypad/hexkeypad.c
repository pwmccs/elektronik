


#define MX_PIC

#define MX_USES_UINT8 1
#define MX_USES_SINT16 0
#define MX_USES_CHAR 0
#define MX_USES_FLOAT 0
#define MX_USES_SINT32 0
#define MX_USES_BOOL 1
#define MX_USES_UINT16 0
#define MX_USES_UINT32 0
//Mikrodenetleyici i�in tan?mlamalar
#define P16F877A
#define FC_CAL_PIC
#define MX_ADC
#define MX_ADC_TYPE_1
#define MX_ADC_BITS_10
#define MX_EE
#define MX_EE_TYPE2
#define MX_EE_SIZE 256
#define MX_SPI_1
#define MX_SPI_1_MISO_PORT portc
#define MX_SPI_1_MISO_TRIS trisc
#define MX_SPI_1_MISO_PIN 4
#define MX_SPI_1_MOSI_PORT portc
#define MX_SPI_1_MOSI_TRIS trisc
#define MX_SPI_1_MOSI_PIN 5
#define MX_SPI_1_CLK_PORT portc
#define MX_SPI_1_CLK_TRIS trisc
#define MX_SPI_1_CLK_PIN 3
#define MX_SPI_1_SS_PORT portc
#define MX_SPI_1_SS_TRIS trisc
#define MX_UART_1
#define MX_UART_1_TX_PORT portc
#define MX_UART_1_TX_TRIS trisc
#define MX_UART_1_TX_PIN 6
#define MX_UART_1_RX_PORT portc
#define MX_UART_1_RX_TRIS trisc
#define MX_UART_1_RX_PIN 7
#define MX_I2C
#define MX_MI2C
#define MX_I2C_1
#define MX_I2C_1_SDA_PORT portc
#define MX_I2C_1_SDA_TRIS trisc
#define MX_I2C_1_SDA_PIN 4
#define MX_I2C_1_SCL_PORT portc
#define MX_I2C_1_SCL_TRIS trisc
#define MX_I2C_1_SCL_PIN 3
#define MX_PWM
#define MX_PWM_CNT 2
#define MX_PWM_PSCA1
#define MX_PWM_PSCA4
#define MX_PWM_PSCA16
#define MX_PWM_1_PORT portc
#define MX_PWM_1_TRIS trisc
#define MX_PWM_1_PIN 2
#define MX_PWM_2_PORT portc
#define MX_PWM_2_TRIS trisc
#define MX_PWM_2_PIN 1

//Fonksiyonlar
#define MX_CLK_SPEED 4000000
#ifdef _BOOSTC
#include <system.h>
#endif
#ifdef HI_TECH_C
#include <pic.h>
#endif

//Dosya yap?land?rmas?
#ifdef _BOOSTC
#pragma DATA 0x2007, 0x3f72
#endif
#ifdef HI_TECH_C
__CONFIG(0x3f72);
#endif

//Dahili fonksiyonlar
#include "C:\Program Files\Flowcode\v5\FCD\internals.c"

//Makro fonksiyon bildirileri


//De?i?ken bildirileri
#define FCV_FALSE (0)
#define FCV_TRUE (1)
MX_UINT8 FCV_SAYI;




//KeyPad(0): //Defines:

/**** Macro Substitutions ****

a = Unique Reference
b = Key List (Numbers)
c = Key List (Characters)
d = Number of Columns
e = Column Port Letter
f = Column Pin Number 0
g = Column Pin Number 1
h = Column Pin Number 2
i = Column Pin Number 3
j = Number of Rows
k = Row Port Letter
l = Row Pin Number 0
m = Row Pin Number 1
n = Row Pin Number 2
o = Row Pin Number 3

******************************/

//Keypad Common Defines

#define Keypad_2_MX_KEYPAD_COL_NUM	4
#define Keypad_2_MX_KEYPAD_COL_PORT	portc
#define Keypad_2_MX_KEYPAD_COL_TRIS	trisc
#define Keypad_2_MX_KEYPAD_COL_PIN0	0
#define Keypad_2_MX_KEYPAD_COL_PIN1	1
#define Keypad_2_MX_KEYPAD_COL_PIN2	2
#define Keypad_2_MX_KEYPAD_COL_PIN3	3
#define Keypad_2_MX_KEYPAD_ROW_NUM	4
#define Keypad_2_MX_KEYPAD_ROW_PORT	portc
#define Keypad_2_MX_KEYPAD_ROW_TRIS	trisc
#define Keypad_2_MX_KEYPAD_ROW_PIN0	4
#define Keypad_2_MX_KEYPAD_ROW_PIN1	5
#define Keypad_2_MX_KEYPAD_ROW_PIN2	6
#define Keypad_2_MX_KEYPAD_ROW_PIN3	7

//Keypad Pin Arrays

ROMARRAY_S Keypad_2_MX_KEYPAD_COL ROMARRAY_E = {
	#if (Keypad_2_MX_KEYPAD_COL_NUM >= 1)
		Keypad_2_MX_KEYPAD_COL_PIN0
	#endif
	#if (Keypad_2_MX_KEYPAD_COL_NUM >= 2)
		,Keypad_2_MX_KEYPAD_COL_PIN1
	#endif
	#if (Keypad_2_MX_KEYPAD_COL_NUM >= 3)
		,Keypad_2_MX_KEYPAD_COL_PIN2
	#endif
	#if (Keypad_2_MX_KEYPAD_COL_NUM >= 4)
		,Keypad_2_MX_KEYPAD_COL_PIN3
	#endif
	};

ROMARRAY_S Keypad_2_MX_KEYPAD_ROW ROMARRAY_E = {
	#if (Keypad_2_MX_KEYPAD_ROW_NUM >= 1)
		Keypad_2_MX_KEYPAD_ROW_PIN0
	#endif
	#if (Keypad_2_MX_KEYPAD_ROW_NUM >= 2)
		,Keypad_2_MX_KEYPAD_ROW_PIN1
	#endif
	#if (Keypad_2_MX_KEYPAD_ROW_NUM >= 3)
		,Keypad_2_MX_KEYPAD_ROW_PIN2
	#endif
	#if (Keypad_2_MX_KEYPAD_ROW_NUM >= 4)
		,Keypad_2_MX_KEYPAD_ROW_PIN3
	#endif
	};

//Keypad Keypress Data Arrays

ROMARRAY_S Keypad_2_mtxKeysAsNumbers ROMARRAY_E = {0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15};
ROMARRAY_S Keypad_2_mtxKeysAsChars ROMARRAY_E = {'0','4','8','C','1','5','9','D','2','6','A','E','3','7','B','F'};




//KeyPad(0): //Makro fonksiyon bildirileri

MX_UINT8 FCD_KeyPad0_GetKeypadNumber();
MX_UINT8 FCD_KeyPad0_GetKeypadAscii();



//KeyPad(0): //Makro uygulamas?


MX_UINT8 FCD_KeyPad0_GetKeypadNumber()
{
	
		MX_UINT8 iCol, iRow, idx;

		for (iCol = 0; iCol < Keypad_2_MX_KEYPAD_COL_NUM; iCol++)
		{
			FC_CAL_Bit_High_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 		//output the appropriate column high
			delay_us(10);																//delay to allow input to settle

			for (iRow = 0; iRow < Keypad_2_MX_KEYPAD_ROW_NUM; iRow++)
			{
				FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_ROW_PORT, Keypad_2_MX_KEYPAD_ROW_TRIS, Keypad_2_MX_KEYPAD_ROW[iRow] );
				if ( FC_CAL_Bit_In ( Keypad_2_MX_KEYPAD_ROW_PORT, Keypad_2_MX_KEYPAD_ROW[iRow] ))
				{
					idx = (iCol * Keypad_2_MX_KEYPAD_ROW_NUM) + iRow;
					FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 	//Allow the column pin to float
					return (Keypad_2_mtxKeysAsNumbers[idx]);
				}
			}
			FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 		//Allow the column pin to float
		}
		return (255);																	//if it gets here, it has not been found...

}

MX_UINT8 FCD_KeyPad0_GetKeypadAscii()
{
	
		MX_UINT8 iCol, iRow, idx;

		for (iCol = 0; iCol < Keypad_2_MX_KEYPAD_COL_NUM; iCol++)
		{
			FC_CAL_Bit_High_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 		//output the appropriate column high
			delay_us(10);																//delay to allow input to settle

			for (iRow = 0; iRow < Keypad_2_MX_KEYPAD_ROW_NUM; iRow++)
			{
				FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_ROW_PORT, Keypad_2_MX_KEYPAD_ROW_TRIS, Keypad_2_MX_KEYPAD_ROW[iRow] );
				if ( FC_CAL_Bit_In ( Keypad_2_MX_KEYPAD_ROW_PORT, Keypad_2_MX_KEYPAD_ROW[iRow] ))
				{
					idx = (iCol * Keypad_2_MX_KEYPAD_ROW_NUM) + iRow;
					FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 	//Allow the column pin to float
					return (Keypad_2_mtxKeysAsChars[idx]);
				}
			}
			FC_CAL_Bit_In_DDR ( Keypad_2_MX_KEYPAD_COL_PORT, Keypad_2_MX_KEYPAD_COL_TRIS, Keypad_2_MX_KEYPAD_COL[iCol] ); 		//Allow the column pin to float
		}
		return (255);																	//if it gets here, it has not been found...

}

#include "C:\Program Files\Flowcode\v5\CAL\includes.c"

//Makro uygulamas?



void main()
{
	//Initialization
	adcon1 = 0x07;


	//Interrupt initialization code
	option_reg = 0xC0;


	//AYAR
	//Hesaplama  :
	//  SAYI = 0
	//  $PORTB = 0
	FCV_SAYI = 0;
	FCP_SET(B, 0xff, 0);

	//D�ng�
	//D�ng�: ?ken 1
	while (1)
	{

		//KONTROL
		//D�ng�: ?ken SAYI = 255
		while (1)
		{

			//Bile?en makrosunu �a??r
			//Bile?en makrosunu �a??r: SAYI=GetKeypadNumber()
			FCV_SAYI = FCD_KeyPad0_GetKeypadNumber();


			if ((FCV_SAYI == 255) == 0) break;
		}

		//TABLO
		// Switch: SAYI?
		switch (FCV_SAYI)
		{
			case 0:
			{
				//0
				//Hesaplama  :
				//  $PORTB = 63
				FCP_SET(B, 0xff, 63);

				break;
			}
			case 1:
			{
				//1
				//Hesaplama  :
				//  $PORTB = 6
				FCP_SET(B, 0xff, 6);

				break;
			}
			case 2:
			{
				//2
				//Hesaplama  :
				//  $PORTB = 91
				FCP_SET(B, 0xff, 91);

				break;
			}
			case 3:
			{
				//3
				//Hesaplama  :
				//  $PORTB = 79
				FCP_SET(B, 0xff, 79);

				break;
			}
			case 4:
			{
				//4
				//Hesaplama  :
				//  $PORTB = 102
				FCP_SET(B, 0xff, 102);

				break;
			}
			case 5:
			{
				//5
				//Hesaplama  :
				//  $PORTB = 109
				FCP_SET(B, 0xff, 109);

				break;
			}
			case 6:
			{
				//6
				//Hesaplama  :
				//  $PORTB = 125
				FCP_SET(B, 0xff, 125);

				break;
			}
			case 7:
			{
				//7
				//Hesaplama  :
				//  $PORTB = 7
				FCP_SET(B, 0xff, 7);

				break;
			}
			case 8:
			{
				//8
				//Hesaplama  :
				//  $PORTB = 127
				FCP_SET(B, 0xff, 127);

				break;
			}
			case 9:
			{
				//9
				//Hesaplama  :
				//  $PORTB = 111
				FCP_SET(B, 0xff, 111);

				break;
			}
			// default:

		}

		//TABLO2
		// Switch: SAYI?
		switch (FCV_SAYI)
		{
			case 10:
			{
				//A
				//Hesaplama  :
				//  $PORTB = 119
				FCP_SET(B, 0xff, 119);

				break;
			}
			case 11:
			{
				//B
				//Hesaplama  :
				//  $PORTB = 124
				FCP_SET(B, 0xff, 124);

				break;
			}
			case 12:
			{
				//C
				//Hesaplama  :
				//  $PORTB = 57
				FCP_SET(B, 0xff, 57);

				break;
			}
			case 13:
			{
				//D
				//Hesaplama  :
				//  $PORTB = 94
				FCP_SET(B, 0xff, 94);

				break;
			}
			case 14:
			{
				//E
				//Hesaplama  :
				//  $PORTB = 121
				FCP_SET(B, 0xff, 121);

				break;
			}
			case 15:
			{
				//F
				//Hesaplama  :
				//  $PORTB = 113
				FCP_SET(B, 0xff, 113);

				break;
			}
			// default:

		}


	}

	mainendloop: goto mainendloop;
}

void MX_INTERRUPT_MACRO(void)
{
}



