#include <12F675.h>
#device adc=8
#FUSES NOWDT, INTRC_IO, NOBROWNOUT, NOCPD, NOPROTECT, NOPUT, MCLR
#use delay(clock=4000000)

#use FIXED_IO( A_outputs=PIN_A2 )
#define LED   PIN_A2
int8 say=0;
int16 on=0, off=0;

void main() {
   setup_adc_ports(sAN0);
   setup_adc(ADC_CLOCK_DIV_64);
   output_low(LED);
   delay_ms(250);
   
   for(say=0; say<3; say++)
   {
   set_adc_channel(0);
   delay_ms(10);
   on=read_adc();
   }
   on++;
   on=(on*2)/1.2;
   off=(426)-on;
   
   
   for(say=0; say<7; say++)
   {
   output_high(LED);
   delay_ms(on);
   output_low(LED);
   delay_ms(off);
   }
   while(TRUE){
   output_high(LED);
   }

}
