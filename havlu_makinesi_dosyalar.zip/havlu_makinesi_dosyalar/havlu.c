#include <16F876A.h>
#device ADC=10
#FUSES NOWDT, NOPUT, NOBROWNOUT, NOLVP, NOCPD, NOWRT, NOPROTECT
#use delay(crystal=4000000)
//#use FIXED_IO( C_outputs=PIN_C5,PIN_C4,PIN_C2,PIN_C1,PIN_C0 )
#use fast_io(c)
#define encoderled   PIN_C0
#define motor   PIN_C1
#define anahtar   PIN_C3
#define bekle   PIN_C4
#define ikaz   PIN_C5
#define encoderc   PIN_C6
#define sensor   PIN_C7
int16 uzunluk=0, zaman=0, sayac=0;
int8 say=0, flag=0, led=15;

#int_TIMER0
void timer0_kesmesi() {
if(++say == led)  
 {               
   say = 0; ++flag;
   if(flag==1) {led = 61;} else {led=15; flag=0;}
   output_toggle(ikaz);
 }
}

void motordongu() {
   disable_interrupts(INT_TIMER0);
   output_high(encoderled);
   output_high(ikaz);
   set_adc_channel(0);
   delay_ms(1);
   uzunluk=read_adc();
   uzunluk=(uzunluk+16)>>5;
   output_high(motor);
   sayac=0;
   delay_ms(100);
   while(sayac<uzunluk) {
      if(!input(encoderc)) {
         ++sayac; 
         while(!input(encoderc)) {delay_us(1);}
         }
      }
   output_low(motor);
   output_low(encoderled);
   delay_ms(10);
   set_adc_channel(1);
   delay_ms(1);
   zaman=read_adc();
   ++zaman;
   output_low(ikaz);
   output_high(bekle);
   while(input(anahtar)) {delay_ms(10);}
   for(int16 z=0;z<zaman;z++) {delay_ms(10);}
   output_low(bekle);
   say=0; flag=1; led=61;
   enable_interrupts(INT_TIMER0);
   }

void main() {
   setup_adc_ports(ALL_ANALOG);
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_timer_2(T2_DIV_BY_1,27,1);      
   setup_ccp1(CCP_PWM);
   set_pwm1_duty((int16)54);     
   set_tris_c(0b11001000);
   output_c(0x00);
   output_high(ikaz);
   led = 15;
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_bit);
   enable_interrupts(INT_TIMER0); 
   enable_interrupts(GLOBAL);
   delay_ms(250);
   
   while(TRUE) {
   set_pwm1_duty((int16)54);
   //for(int i=0;i<10;i++) {   
      delay_ms(100);
      if(!input(sensor)){motordongu();}
      
   //}
   set_pwm1_duty((int16)0);
   delay_ms(100);
   }
}
