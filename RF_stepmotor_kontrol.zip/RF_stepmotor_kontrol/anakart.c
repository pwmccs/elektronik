#include <16F876A.h>
#FUSES XT, NOPUT, NOBROWNOUT, NOLVP, NOCPD, NOWRT, NOPROTECT, NOWDT
#use delay(crystal=4MHz)
#use rs232(baud=2400,parity=N,rcv=PIN_A0,bits=8,INVERT,TIMEOUT=1)
#use fast_io(a)
#use fast_io(b)
#use fast_io(c)
#define LCD_ENABLE_PIN PIN_B3
#define LCD_RS_PIN PIN_B1
#define LCD_RW_PIN PIN_B2
#define LCD_DATA4 PIN_B4
#define LCD_DATA5 PIN_B5
#define LCD_DATA6 PIN_B6
#define LCD_DATA7 PIN_B7
#include <lcd.c>
char e;
int16 adim=0,hiz=0,sayac=0,say=0,t=0;
int8 ahg=0,alw=0,hhg=0,hlw=0,step=0,bayrak=0;
int motorsag[4]={0b01000011,0b01000110,0b01001100,0b01001001};
int motorsol[4]={0b10000110,0b10000011,0b10001001,0b10001100};


void main()
{
   setup_adc_ports(NO_ANALOGS); 
   setup_adc(ADC_OFF);
   setup_comparator(NC_NC_NC_NC);
   set_tris_a(0xFF);
   set_tris_b(0x00);
   set_tris_c(0x00);
   output_b(0);
   output_c(0);
   delay_ms(250);
   lcd_init();
   lcd_gotoxy(1,1);
   printf(lcd_putc,"  RF STEPMOTOR  ");
   lcd_gotoxy(1,2);
   printf(lcd_putc,"Komut Bekleniyor");
   while(TRUE)
   {
       if(getch()=='X')
         {
         e=getch();
         alw=getch();
         ahg=getch();
         hlw=getch();
         hhg=getch();
         adim = make16(ahg,alw);
         hiz = make16(hhg,hlw);
         sayac=1025-hiz;
         lcd_gotoxy(1,1);
         printf(lcd_putc,"\f ADIM=%lu    \n HIZ=%lu   ",adim,hiz,);
         
         if(e=='L')
            {
            for(say=0;say<adim;say++) 
              { 
              output_c(motorsol[step]);
                  for(t=0;t<sayac;t++) 
                        {
                         if(getch()=='Y')
                              {
                              if(getch()=='S')
                                 {
                                 output_c(0x00);
                                 bayrak=1; 
                                 break;
                                 }
                              }
                        } 
              if(++step==4){step=0;}
              if(bayrak==1)
              {
                 bayrak=0;
                 break;
                }
              }
              output_c(0x00);
              lcd_gotoxy(1,1);
              printf(lcd_putc,"\fMOTOR DURDURULDU");
              delay_ms(3000); 
              lcd_gotoxy(1,1);
              printf(lcd_putc,"\f ADIM=%lu    \n HIZ=%lu    ",adim,hiz,);
            }
         
         
         if(e=='R')
            {
            for(say=0;say<adim;say++) 
              { 
              output_c(motorsag[step]);
                  for(t=0;t<sayac;t++) 
                        {
                         if(getch()=='Y')
                              {
                              if(getch()=='S')
                                 {
                                 output_c(0x00);
                                 bayrak=1; 
                                 break;
                                 }
                              }
                        } 
              if(++step==4){step=0;}
              if(bayrak==1)
                 {
                 bayrak=0;
                 break;
                }
              }
              output_c(0x00);
              lcd_gotoxy(1,1);
              printf(lcd_putc,"\fMOTOR DURDURULDU");
              delay_ms(3000);
              lcd_gotoxy(1,1);
              printf(lcd_putc,"\f ADIM=%lu    \n HIZ=%lu    ",adim,hiz,);
            }
         
         }
         
   }

}

