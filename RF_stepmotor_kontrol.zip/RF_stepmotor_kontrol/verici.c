#include <12F675.h>
#device ADC=10
#FUSES INTRC_IO, NOPUT, NOMCLR, NOBROWNOUT, NOPROTECT, NOCPD
#use delay(internal=4MHz)
#use rs232(baud=2400,parity=N,xmit=PIN_A5,INVERT,bits=8)
#use fast_io(a)
#define SOL   PIN_A2
#define DUR   PIN_A3
#define SAG   PIN_A4

int16 adim=0,hiz=0;
int8 ahg=0,alw=0,hhg=0,hlw=0;

void potoku(){
   set_adc_channel(0);
   delay_ms(1);
   adim=read_adc();
   ++adim;
   set_adc_channel(1);
   delay_ms(1);
   hiz=read_adc();
   ++hiz;
   alw = make8(adim,0);
   ahg = make8(adim,1);
   hlw = make8(hiz,0);
   hhg = make8(hiz,1);
}

void main()
{
   setup_adc_ports(sAN0|sAN1);
   setup_adc(ADC_CLOCK_INTERNAL);
   set_tris_a(0b11011111);
   output_a(0x00);
   delay_ms(250);
   
   while(TRUE)
   {
    if(!input(SOL))
      {
      potoku();
      putc(0b01010101);
      putc('X');
      putc('L');
      putc(alw);
      putc(ahg);
      putc(hlw);
      putc(hhg);
      delay_ms(10);
      output_low(PIN_A5);
      }
     if(!input(SAG))
      {
      potoku();
      putc(0b01010101);
      putc('X');
      putc('R');
      putc(alw);
      putc(ahg);
      putc(hlw);
      putc(hhg);
      delay_ms(10);
      output_low(PIN_A5);
      }
     if(!input(DUR))
      {
      putc(0b01010101);
      putc('Y');
      putc('S');
      delay_ms(10);
      output_low(PIN_A5);
      }
   }

}
