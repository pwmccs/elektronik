#include <12F683.h>
#FUSES PUT, NOMCLR, NOPROTECT, NOCPD, NOBROWNOUT, NOIESO, NOFCMEN, INTRC_IO
#use delay(internal=8MHz)
#use FIXED_IO( A_outputs=PIN_A2 )

int16 i=0;

void main() {
   setup_timer_2(T2_DIV_BY_4,124,1);     
   setup_ccp1(CCP_PWM);
   set_pwm1_duty((int16)0);
   delay_ms(250);
   
   while(TRUE)
   {
    for(i=0;i<500;i++)
         {
         set_pwm1_duty((int16)i);
         delay_us(500);
         }
    for(i=500;i>0;i--)
         {
         set_pwm1_duty((int16)i);
         delay_us(500);
         }
         
    for(i=0;i<255;i++)
         {
         set_pwm1_duty((int16)i);
         delay_ms(1);
         }
    for(i=255;i>0;i--)
         {
         set_pwm1_duty((int16)i);
         delay_ms(1);
         }
   set_pwm1_duty((int16)0);
   delay_ms(1000);
   }

}

